import React from 'react';
import {Handle,Position} from '@xyflow/react';
export const OV_PINS=[[952,22],[952,160],[952,380],[952,440],[952,605],[952,660],[952,790],[952,850]];
const VB={x:-26,w:990,h:970};
const TOOLS=[
 ['점 (Point)','클릭한 한 곳',<g key="a"><circle cx="26" cy="26" r="9" fill="none" stroke="#ffcf33" strokeWidth="5"/><circle cx="26" cy="26" r="3" fill="#ffcf33"/></g>],
 ['상자 (Box)','상자 안쪽 전부',<rect key="b" x="9" y="13" width="34" height="26" fill="none" stroke="#ffcf33" strokeWidth="5"/>],
 ['붓 (Scribble)','붓이 지난 곳',<path key="c" d="M7 33 C15 11 24 43 32 22 S42 15 46 19" fill="none" stroke="#ffcf33" strokeWidth="5.5" strokeLinecap="round"/>],
 ['올가미 (Lasso)','닫은 선 안쪽',<path key="d" d="M10 29 C7 14 28 8 40 16 C48 25 38 41 25 41 C17 41 12 36 10 29Z" fill="none" stroke="#ffcf33" strokeWidth="4.5" strokeDasharray="2 7" strokeLinecap="round"/>],
];
const CH=[['0','직전 결과','이전 예측','prev'],['1','상자·올가미','+ 포함','pos'],['2','상자·올가미','− 제외','neg'],['3','점','+ 포함','pos'],['4','점','− 제외','neg'],['5','붓','+ 포함','pos'],['6','붓','− 제외','neg']];
const MASK=['0001110000','0111111100','1111111110','0111111110','0011111100','0000111000'];
const arrow=(x1,y1,x2,y2,k)=><line key={k} x1={x1} y1={y1} x2={x2} y2={y2} stroke="var(--muted)" strokeWidth="2.4" markerEnd="url(#oah)"/>;
const Num=({n,x,y,c='var(--ink)'})=><g><circle cx={x} cy={y} r="13" fill={c}/><text x={x} y={y+5} textAnchor="middle" fontSize="14" fontWeight="800" fill="var(--card)">{n}</text></g>;
const Head=({n,x,y,t,s})=><g><Num n={n} x={x+13} y={y}/><text x={x+36} y={y+6} fontSize="19" fontWeight="800" fill="var(--ink)">{t}</text>{s&&<text x={x+36+t.length*19*0.98} y={y+6} fontSize="14.5" fill="var(--muted)"> {s}</text>}</g>;
export function OverviewBody(){
  return (<div style={{position:'relative'}}>
  <svg className="ovfig" viewBox={`${VB.x} 0 ${VB.w} ${VB.h}`} width="100%" role="img" aria-label="nnInteractive 한 판 정리" style={{display:'block'}}>
   <defs><marker id="oah" viewBox="0 0 10 10" refX="8" refY="5" markerUnits="userSpaceOnUse" markerWidth="14" markerHeight="14" orient="auto"><path d="M0 0L10 5L0 10z" fill="context-stroke"/></marker></defs>
   {/* ⓪ */}
   <rect x="0" y="0" width="940" height="44" rx="12" fill="var(--accent-soft)"/>
   <text x="470" y="28" textAnchor="middle" fontSize="17" fontWeight="700" fill="var(--accent)">⓪ 준비 — Initialize: CT를 서버에 한 번 올리고 세션을 만든다</text>
   {/* ① */}
   <Head n="1" x={0} y={84} t="내가 하는 것" s="2D 슬라이스 위에서"/>
   {TOOLS.map((t,i)=>(<g key={i} transform={`translate(${i*202},110)`}>
     <rect width="190" height="104" rx="16" fill="var(--card)" stroke="var(--line2)" strokeWidth="1.4"/>
     <g transform="translate(16,26)"><rect width="52" height="52" rx="12" fill="#1c1c1f"/>{React.cloneElement(t[2])}</g>
     <text x="82" y="52" fontSize="17" fontWeight="800" fill="var(--ink)">{t[0]}</text>
     <text x="82" y="76" fontSize="14.5" fill="var(--muted)">{t[1]}</text></g>))}
   <g transform="translate(820,110)"><rect width="120" height="104" rx="16" fill="var(--grey)"/>
     <rect x="14" y="16" width="92" height="32" rx="16" fill="var(--pos)" fillOpacity=".16" stroke="var(--pos)" strokeWidth="1.8"/><text x="60" y="38" textAnchor="middle" fontSize="15" fontWeight="800" fill="var(--pos)">+ 포함</text>
     <rect x="14" y="56" width="92" height="32" rx="16" fill="var(--neg)" fillOpacity=".16" stroke="var(--neg)" strokeWidth="1.8"/><text x="60" y="78" textAnchor="middle" fontSize="15" fontWeight="800" fill="var(--neg)">− 제외</text></g>
   <text x="880" y="232" textAnchor="middle" fontSize="12.5" fill="var(--muted)">모든 도구 공통</text>
   {arrow(470,246,470,282,'a1')}
   {/* ② */}
   <Head n="2" x={0} y={316} t="숫자 지도로 바꿔서 기록" s="7채널 + CT = 8채널"/>
   {CH.map((c,i)=>(<g key={i} transform={`translate(${i*104},346)`}>
     <rect width="94" height="116" rx="14" fill={`var(--${c[3]})`} fillOpacity=".13" stroke={`var(--${c[3]})`} strokeWidth="2"/>
     <circle cx="24" cy="26" r="13" fill={`var(--${c[3]})`}/><text x="24" y="31" textAnchor="middle" fontSize="14" fontWeight="800" fill="#fff">{c[0]}</text>
     <text x="47" y="74" textAnchor="middle" fontSize="15" fontWeight="800" fill="var(--ink)">{c[1]}</text>
     <text x="47" y="98" textAnchor="middle" fontSize="13.5" fill="var(--muted)">{c[2]}</text></g>))}
   <text x="738" y="414" textAnchor="middle" fontSize="26" fontWeight="800" fill="var(--muted)">+</text>
   <g transform="translate(762,346)"><rect width="178" height="116" rx="14" fill="var(--grey)" stroke="var(--line2)" strokeWidth="2" strokeDasharray="5 5"/>
     <text x="89" y="56" textAnchor="middle" fontSize="20" fontWeight="800" fill="var(--ink)">CT 영상</text><text x="89" y="82" textAnchor="middle" fontSize="13.5" fill="var(--muted)">평균·표준편차로 정규화</text></g>
   {arrow(470,476,470,514,'a2')}
   {/* ③ */}
   <Head n="3" x={0} y={546} t="신경망이 한 번에 계산" s="클릭 위치 중심 조각만"/>
   <g transform="translate(6,574)">{/* cube */}
     <polygon points="0,26 62,26 62,90 0,90" fill="var(--accent-soft)" stroke="var(--accent)" strokeWidth="2"/>
     <polygon points="0,26 24,4 86,4 62,26" fill="var(--accent-soft)" stroke="var(--accent)" strokeWidth="2"/>
     <polygon points="62,26 86,4 86,68 62,90" fill="var(--accent-soft)" stroke="var(--accent)" strokeWidth="2" opacity=".85"/>
     <text x="43" y="112" textAnchor="middle" fontSize="13.5" fontWeight="700" fill="var(--accent)">192×192×192</text></g>
   {arrow(112,624,166,624,'a3')}
   <g transform="translate(176,570)"><rect width="372" height="104" rx="16" fill="var(--card)" stroke="var(--line2)" strokeWidth="1.4"/>
     {[88,66,46,30,46,66,88].map((h,i)=>(<rect key={i} x={20+i*30} y={14+(88-h)/2+ (0)} width="20" height={h} rx="5" fill="var(--accent)" fillOpacity={i===3?1:.28+ (i<3?i:6-i)*.07}/>))}
     <path d="M30 18 Q 123 -6 216 18 M60 18 Q 123 4 186 18" fill="none" stroke="var(--accent)" strokeWidth="0"/>
     <text x="246" y="46" fontSize="17" fontWeight="800" fill="var(--ink)">ResEnc U-Net</text><text x="246" y="70" fontSize="13.5" fill="var(--muted)">(nnU-Net 계열)</text><text x="246" y="90" fontSize="13.5" fill="var(--muted)">8채널 입력</text></g>
   {arrow(552,624,596,624,'a4')}
   <g transform="translate(606,586)"><rect width="150" height="80" rx="14" fill="var(--card)" stroke="var(--line2)" strokeWidth="1.4"/><text x="75" y="34" textAnchor="middle" fontSize="15" fontWeight="800" fill="var(--ink)">배경 / 대상</text><text x="75" y="58" textAnchor="middle" fontSize="13.5" fill="var(--muted)">큰 쪽 → 0/1 조각</text></g>
   <g transform="translate(776,570)"><rect width="164" height="104" rx="16" fill="var(--grey)"/>
     <rect x="64" y="30" width="36" height="36" fill="none" stroke="var(--accent)" strokeWidth="2"/><rect x="50" y="18" width="64" height="62" fill="none" stroke="var(--accent)" strokeWidth="2" strokeDasharray="4 4" opacity=".7"/><rect x="34" y="6" width="96" height="88" fill="none" stroke="var(--accent)" strokeWidth="2" strokeDasharray="2 5" opacity=".45"/><circle cx="82" cy="48" r="4" fill="#ffcf33" stroke="#1c1c1f"/>
     <text x="82" y="118" textAnchor="middle" fontSize="13" fontWeight="800" fill="var(--accent)">AutoZoom ×1 → ×4</text></g>
   {arrow(470,700,470,738,'a5')}
   {/* ④ 간 마스크 */}
   <Head n="4" x={0} y={768} t="간 마스크" s="간이면 1, 아니면 0"/>
   <g transform="translate(0,792)"><rect width="300" height="108" rx="16" fill="var(--card)" stroke="var(--line2)" strokeWidth="1.4"/>
     {MASK.map((row,r)=>row.split('').map((v,c)=>(<rect key={r+'-'+c} x={14+c*17} y={14+r*14} width="15" height="12" rx="3" fill={v==='1'?'var(--pos)':'var(--grey)'} fillOpacity={v==='1'?.85:1}/>)))}
     <text x="244" y="48" textAnchor="middle" fontSize="13.5" fill="var(--muted)">Slicer의</text><text x="244" y="68" textAnchor="middle" fontSize="13.5" fontWeight="800" fill="var(--ink)">Liver 세그먼트</text></g>
   {arrow(308,846,346,846,'a6')}
   {/* ⑤ 되먹임 */}
   <g transform="translate(356,800)"><rect width="584" height="92" rx="16" fill="var(--prev)" fillOpacity=".13" stroke="var(--prev)" strokeWidth="2"/>
     <circle cx="30" cy="30" r="13" fill="var(--prev)"/><text x="30" y="35" textAnchor="middle" fontSize="14" fontWeight="800" fill="#fff">5</text>
     <text x="54" y="36" fontSize="18" fontWeight="800" fill="var(--ink)">되먹임</text>
     <text x="24" y="68" fontSize="15" fill="var(--ink)">이 마스크가 다음 계산의 <tspan fontWeight="800" fill="var(--prev)">채널 0</tspan>이 돼요 → 클릭을 더할수록 다듬어져요</text></g>
   <path d="M648 892 V930 H-14 V404 H-4" fill="none" stroke="var(--prev)" strokeWidth="3" strokeDasharray="9 7" markerEnd="url(#oah)"/>
   <text x="330" y="954" textAnchor="middle" fontSize="14" fontWeight="700" fill="var(--prev)">채널 0으로 돌아가요</text>
   </svg>
   {OV_PINS.map((p,i)=>(<div key={i} className="pin" style={{left:((p[0]-VB.x)/VB.w*100)+'%',top:(p[1]/VB.h*100)+'%'}}>{i+1}<Handle id={'p'+(i+1)} type="source" position={Position.Right} className="hd" style={{left:'100%',top:'50%',right:'auto',transform:'translate(0,-50%)'}}/></div>))}
   </div>);
}
