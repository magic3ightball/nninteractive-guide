import React from 'react';import {createRoot} from 'react-dom/client';import '@xyflow/react/dist/style.css';import './orig.css';import './legacy.css';import './app.css';import App from './App.jsx';
createRoot(document.getElementById('root')).render(<App/>);
