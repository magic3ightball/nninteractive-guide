import React,{useCallback,useEffect,useMemo,useRef,useState,createContext,useContext} from 'react';
import {ReactFlow,ReactFlowProvider,Background,MiniMap,Controls,Panel,Handle,Position,useReactFlow,MarkerType} from '@xyflow/react';
import D from './data2.json';
import {OverviewBody,OV_PINS} from './OverviewCard.jsx';

const {ROWS,NOTES,NUM,W,NOTE_X,NOTE_W,rects,frames}=D;
const OV_HEAD=128,OV_SC=0.975;
const ORDER=ROWS.flatMap(r=>r.ids);
const Ctx=createContext({focus:()=>{},annOn:true});

/* ---------- 노드 ---------- */
function CardNode({data,selected}){
  return (<div className={'frame'+(selected?' sel':'')} onDoubleClick={()=>data.onZoom(data.id)}>
    <div className="fname fhandle">{data.num} · {data.title}</div>
    <Handle id="in" type="target" position={Position.Left} className="hd" style={{top:44}}/>
    <Handle id="out" type="source" position={Position.Right} className="hd" style={{top:44}}/>
    {data.custom==='overview'
      ? <div className="fbody nodrag"><section className="card"><div dangerouslySetInnerHTML={{__html:data.head}}/><OverviewBody/><div dangerouslySetInnerHTML={{__html:data.tail}}/></section></div>
      : <div className="fbody nodrag" dangerouslySetInnerHTML={{__html:data.html}}/>}
    <div className="cover"><div className="ct">{data.title}</div><div className="cs">{data.take}</div></div>
    {!data.custom&&data.pins.map(p=>(<div key={p.n} className="pin" style={{left:p.x,top:p.y}} data-pin={data.id+p.n}>{p.n}
      <Handle id={'p'+p.n} type="source" position={Position.Right} className="hd" style={{left:'100%',top:'50%',right:'auto',transform:'translate(0,-50%)'}}/></div>))}
  </div>);
}
function NoteNode({data}){
  const {focus}=useContext(Ctx);
  return (<div className="note" style={{width:NOTE_W}}>
    <Handle id="l" type="target" position={Position.Left} className="hd" style={{top:22}}/>
    <span className="nn">{data.n}</span>
    <div className="nb"><div className="nh">{data.h}</div><div className="nt">{data.t}</div>
      {data.to&&<button className="nl nodrag" onClick={()=>focus(data.to)}>{NUM[data.to]} · {frames[data.to].title} ▸</button>}</div>
  </div>);
}
function SectionNode({data}){
  return (<div className="rowlabel">
    <Handle id="t" type="target" position={Position.Top} className="hd"/>
    <div className="rt">{data.t}</div><div className="rs">{data.s} · 카드 {data.count}개</div>
    <Handle id="b" type="source" position={Position.Bottom} className="hd"/>
    <Handle id="r" type="source" position={Position.Right} className="hd" style={{top:40}}/>
  </div>);
}
const nodeTypes={card:CardNode,note:NoteNode,section:SectionNode};

/* ---------- 그래프 데이터 ---------- */
function build(onZoom){
  const nodes=[],edges=[];const cnt={};
  const pinsBy={};D.pins.forEach(p=>{(pinsBy[p.f]=pinsBy[p.f]||[]).push(p)});
  const notesBy={};D.notes.forEach(p=>{(notesBy[p.f]=notesBy[p.f]||[]).push(p)});
  const ACC={color:'#4f46e5'};
  ROWS.forEach((r,ri)=>{
    const first=rects[r.ids[0]];
    nodes.push({id:'sec'+ri,type:'section',position:{x:-1250,y:first.y-70},data:{...r,count:r.ids.length},draggable:true});
    edges.push({id:'sec-in'+ri,source:'sec'+ri,sourceHandle:'r',target:r.ids[0],targetHandle:'in',className:'flow',type:'default'});
    if(ri<ROWS.length-1)edges.push({id:'sec-seq'+ri,source:'sec'+ri,sourceHandle:'b',target:'sec'+(ri+1),targetHandle:'t',className:'rowflow',animated:true,type:'default',markerEnd:{type:MarkerType.ArrowClosed,width:22,height:22,color:'#4f46e5'}});
    r.ids.forEach((id,ci)=>{
      const rc=rects[id];
      const pins=(pinsBy[id]||[]).map((p,i)=>({n:i+1,x:p.x-rc.x,y:p.y-rc.y}));
      nodes.push({id,type:'card',position:{x:rc.x,y:rc.y},style:{width:W},dragHandle:'.fhandle',data:{id,num:NUM[id],title:frames[id].title,take:frames[id].take,html:frames[id].html,pins,onZoom,...(id==='overview'?{custom:'overview',head:frames[id].html.split('<svg')[0].replace('</section>',''),tail:frames[id].html.slice(frames[id].html.lastIndexOf('</svg>')+6).replace('</section>','')}:{})}});
      let nlist=NOTES[id]||[];let ntops=notesBy[id];
      if(id==='overview'){const ord=[0,1,2,3,4,7,5,6];nlist=ord.map(k=>nlist[k]);const hs=ord.map(k=>notesBy[id][k].h);let prev=rc.y+100;ntops=ord.map((k,i)=>{const t=Math.max(prev,rc.y+OV_HEAD+OV_PINS[i][1]*OV_SC-30);prev=t+hs[i]+16;return{top:t}})}
      nlist.forEach((n,i)=>{
        const nt=ntops[i];const nid=`${id}-n${i+1}`;
        nodes.push({id:nid,type:'note',position:{x:rc.x+W+NOTE_X,y:nt.top},data:{n:i+1,h:n.h,t:n.t,to:n.to,f:id},className:'annot'});
        edges.push({id:'ld-'+nid,source:id,sourceHandle:'p'+(i+1),target:nid,targetHandle:'l',className:'leader',zIndex:20,type:'default'});
      });
      if(ci<r.ids.length-1){
        edges.push({id:'fl-'+id,source:id,sourceHandle:'out',target:r.ids[ci+1],targetHandle:'in',type:'straight',className:'flow',label:`${NUM[id]} → ${NUM[r.ids[ci+1]]}`,markerEnd:{type:MarkerType.ArrowClosed,width:26,height:26,color:'#4f46e5'}});
      }
    });
  });
  return {nodes,edges};
}
const all=Object.values(rects);
const BOUNDS={x:-1270,y:-40,width:Math.max(...all.map(r=>r.x+r.w+NOTE_X+NOTE_W))+1310,height:Math.max(...all.map(r=>Math.max(r.y+r.h,r.nb||0)))+80};
const LEFT=innerWidth>900?270:20;

function Board(){
  const rf=useReactFlow();const wrap=useRef(null);
  const [annOn,setAnnOn]=useState(true);const [tourI,setTourI]=useState(-1);const [sel,setSel]=useState(null);
  const onZoom=useCallback(id=>focusRef.current(id,false),[]);
  const focusRef=useRef(()=>{});
  const g=useMemo(()=>build(onZoom),[onZoom]);
  const [nodes,setNodes]=useState(g.nodes);
  const onNodesChange=useCallback(ch=>setNodes(ns=>applyChanges(ch,ns)),[]);
  const inited=useNodesInitialized();const restacked=useRef(false);const upInt=useUpdateNodeInternals();
  const anchorPt=(frameEl,a)=>{const fb=frameEl.getBoundingClientRect();const k=fb.width/frameEl.offsetWidth;
    if(a.svg){const svg=frameEl.querySelectorAll('svg.fig')[a.i||0];const p=svg.createSVGPoint();p.x=a.svg[0];p.y=a.svg[1];const q=p.matrixTransform(svg.getScreenCTM());return{x:(q.x-fb.left)/k,y:(q.y-fb.top)/k}}
    const el=frameEl.querySelectorAll(a.sel)[a.i||0];const r=el.getBoundingClientRect();const x=a.at==='l'?r.left+14*k:a.at==='c'?(r.left+r.right)/2:r.right+16*k;return{x:(x-fb.left)/k,y:((r.top+r.bottom)/2-fb.top)/k}};
  useEffect(()=>{if(!inited||restacked.current)return;restacked.current=true;
    setNodes(ns=>{const pos={};ns.forEach(n=>{if(n.type==='card')pos[n.id]=n.position});
      const pinsNew={};const want={};
      ROWS.forEach(r=>r.ids.forEach(id=>{if(id==='overview')return;const fe=document.querySelector(`.react-flow__node[data-id="${id}"] .frame`);if(!fe)return;
        pinsNew[id]=(NOTES[id]||[]).map((n,i)=>{try{const p=anchorPt(fe,n.a);want[`${id}-n${i+1}`]=pos[id].y+p.y-30;return{n:i+1,x:p.x,y:p.y}}catch(e){return{n:i+1,x:1000,y:60*i+40}}})}));
      const by={};ns.forEach(n=>{if(n.type==='note')(by[n.data.f]=by[n.data.f]||[]).push(n)});const upd={};
      Object.values(by).forEach(list=>{list.sort((a,b)=>a.data.n-b.data.n);let prev=-1e9;list.forEach(n=>{const h=n.measured?.height||120;const y=Math.max(want[n.id]??n.position.y,prev+16);upd[n.id]=y;prev=y+h})});
      return ns.map(n=>n.type==='card'&&pinsNew[n.id]?{...n,data:{...n.data,pins:pinsNew[n.id]}}:upd[n.id]!=null?{...n,position:{...n.position,y:upd[n.id]}}:n)});
    [60,400,1200].forEach(t=>setTimeout(()=>ORDER.forEach(id=>upInt(id)),t))},[inited]);
  const noteRect=(id,withNotes)=>{const r=rects[id];const wn=withNotes&&annOn;return{x:r.x-30,y:r.y-60,width:wn?W+NOTE_X+NOTE_W+70:W+60,height:Math.max(r.h,wn?r.nb-r.y:0)+90}};
  const focus=useCallback((id,withNotes=true)=>{setSel(id);setTourI(ORDER.indexOf(id));
    rf.fitBounds(noteRect(id,withNotes),{padding:{top:'70px',left:LEFT+'px',right:'30px',bottom:'30px'},duration:600});},[rf,annOn]);
  focusRef.current=focus;
  const fitAll=useCallback(()=>{setSel(null);setTourI(-1);rf.fitBounds(BOUNDS,{padding:{top:'70px',left:LEFT+'px',right:'30px',bottom:'30px'},duration:600})},[rf]);
  const step=useCallback(d=>{const i=tourI<0?(d>0?0:ORDER.length-1):Math.min(ORDER.length-1,Math.max(0,tourI+d));focus(ORDER[i])},[tourI,focus]);
  const lod=z=>{const el=wrap.current;if(!el)return;el.style.setProperty('--inv',(1/z).toFixed(3));el.style.setProperty('--ps',Math.min(3.2,Math.max(1,.9/z)).toFixed(2));el.classList.toggle('far',z<.3);el.classList.toggle('mid',z>=.3&&z<.62)};
  useEffect(()=>{const h=e=>{if(e.target.matches&&e.target.matches('input'))return;
    if(e.key==='ArrowRight'||e.key===']'){e.preventDefault();step(1)}else if(e.key==='ArrowLeft'||e.key==='['){e.preventDefault();step(-1)}
    else if(e.key==='!'||(e.shiftKey&&e.code==='Digit1'))fitAll();else if(e.key==='a'||e.key==='A')setAnnOn(v=>!v);else if(e.key==='Escape')setSel(null)};
    addEventListener('keydown',h);return()=>removeEventListener('keydown',h)},[step,fitAll]);
  const shown=useMemo(()=>nodes.map(n=>n.type==='card'?{...n,selected:n.id===sel}:n),[nodes,sel]);
  return (<Ctx.Provider value={{focus,annOn}}>
   <div ref={wrap} className={'rfwrap'+(annOn?'':' noann')} style={{width:'100vw',height:'100vh'}}>
    <ReactFlow nodes={shown} edges={g.edges} nodeTypes={nodeTypes} onNodesChange={onNodesChange}
      minZoom={.03} maxZoom={4} panOnScroll panOnDrag zoomOnDoubleClick={false} selectionOnDrag={false} nodesConnectable={false} elementsSelectable
      colorMode="system" proOptions={{hideAttribution:true}} onlyRenderVisibleElements={false}
      onInit={()=>{rf.fitBounds(BOUNDS,{padding:{top:'70px',left:LEFT+'px',right:'30px',bottom:'30px'},duration:0});lod(rf.getZoom())}}
      onMove={(e,vp)=>lod(vp.zoom)} onNodeClick={(e,n)=>{if(n.type==='card'){setSel(n.id);setTourI(ORDER.indexOf(n.id))}}} onPaneClick={()=>setSel(null)}>
      <Background gap={24} size={1.4} color="var(--dot)"/>
      <MiniMap pannable zoomable position="bottom-right" nodeColor={n=>n.type==='card'?'#a8aec0':n.type==='note'?'#e9dc8a':'#4f46e5'} maskColor="rgba(120,120,140,.12)"/>
      <Controls position="bottom-left" showInteractive={false} fitViewOptions={{}} onFitView={fitAll}/>
      <Panel position="top-left" className="pill" style={{margin:14,padding:8,width:232,maxHeight:'calc(100vh - 190px)',overflow:'auto'}}>
        <div id="layers">{ROWS.map(r=>(<div key={r.t}><h4>{r.t}</h4>{r.ids.map(id=>(<button key={id} className={sel===id?'on':''} onClick={()=>focus(id)}><span className="ln">{NUM[id]}</span>{frames[id].title}</button>))}</div>))}</div>
      </Panel>
      <Panel position="top-center" className="pill tour">
        <button disabled={tourI<=0} onClick={()=>step(-1)}>◀</button>
        <div className="tinfo"><span className="tn">{tourI>=0?`${tourI+1} / ${ORDER.length}`:'흐름 따라가기'}</span><span className="tt">{tourI>=0?frames[ORDER[tourI]].title:'▶ 눌러서 1단계부터 시작'}</span></div>
        <button disabled={tourI>=ORDER.length-1} onClick={()=>step(1)}>▶</button><span className="sep"/>
        <label className="ann"><input type="checkbox" checked={annOn} onChange={e=>setAnnOn(e.target.checked)}/> 주석</label>
      </Panel>
      <Panel position="top-right" className="pill help"><b>두 손가락</b> 이동 · <b>핀치 / ⌘+스크롤</b> 확대 · <b>드래그</b> 이동<br/><b>← →</b> 흐름 따라가기 · <b>Shift+1</b> 전체 · <b>더블클릭</b> 카드로 확대 · <b>A</b> 주석<br/>카드 이름표를 끌면 카드를 옮길 수 있어요</Panel>
      <Panel position="bottom-center" className="pill legend"><span><i style={{background:'var(--pos)'}}/>Positive (포함)</span><span><i style={{background:'var(--neg)'}}/>Negative (제외)</span><span><i style={{background:'var(--prev)'}}/>직전 결과</span><span><i style={{background:'var(--gest)'}}/>내가 한 동작</span></Panel>
    </ReactFlow>
   </div></Ctx.Provider>);
}
import {applyNodeChanges,useNodesInitialized,useUpdateNodeInternals} from '@xyflow/react';
const applyChanges=applyNodeChanges;
export default function App(){return <ReactFlowProvider><Board/></ReactFlowProvider>}
