import json,sys
sys.path.insert(0,'/tmp/claude-0/-home-claude/3cc46b7b-7de1-5df6-a70a-f3b4eab168c5/scratchpad/v3')
import build
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1600,'height':1000})
    pg.goto('file://'+build.OUT); pg.wait_for_timeout(1200)
    d=pg.evaluate('''()=>{
      const frames={};document.querySelectorAll('.frame').forEach(f=>{frames[f.dataset.id]={title:TITLE[f.dataset.id],take:f.querySelector('.cs').textContent,html:f.querySelector('.fbody').innerHTML}});
      const pins=[...document.querySelectorAll('.pin')].map(e=>({f:e.dataset.f,x:parseFloat(e.style.left),y:parseFloat(e.style.top)}));
      const notes=[...document.querySelectorAll('.note')].map(e=>({f:e.dataset.f,top:parseFloat(e.style.top),h:e.offsetHeight}));
      return {frames,rects,pins,notes,ROWS,NOTES,NUM,W,NOTE_X,NOTE_W}}''')
    b.close()
json.dump(d,open('src/data.json','w'),ensure_ascii=False)
# css
css=build.orig_css
keep=[l for l in build.CSS.split('\n') if l.startswith('.frame') or l.startswith('html[lang]:root') or l.startswith('@media(prefers-color-scheme:dark){html[lang]')or l.startswith(' --pos') or l.startswith('.cover') or l.startswith('.rowlabel') or l.startswith('.fname') or l.startswith('.far ') or l.startswith('.pin')or l.startswith('.note')or l.startswith('@media(prefers-color-scheme:dark){.note')]
open('src/orig.css','w').write(css)
open('src/legacy.css','w').write('\n'.join(keep))
print(len(d['frames']),len(d['pins']),len(d['notes']),'img' , sum(h['html'].count('<img') for h in d['frames'].values()))
