import json,re,os
HERE=os.path.dirname(os.path.abspath(__file__))
D=json.load(open(HERE+'/src/data.json'))
SVG_RE=re.compile(r'<svg class="fig".*?</svg>',re.S)
def old_svgs(i): return SVG_RE.findall(D['frames'][i]['html'])
def apply(i):
    """returns (html, notes) for card i with new svgs / anchors if present in cards/"""
    h=D['frames'][i]['html']; notes=json.loads(json.dumps(D['NOTES'].get(i,[])))
    p=f'{HERE}/cards/{i}.svgs.html'
    if os.path.exists(p):
        new=re.findall(r'<svg class="fig".*?</svg>',open(p,encoding='utf8').read(),flags=re.S)
        def fixtext(s):
            def tag(mm):
                t=mm.group(0)
                f=re.search(r'\sfill="([^"]+)"',t)
                if f and not re.search(r'style="[^"]*fill:',t):
                    t=t.replace(f.group(0),'',1)
                    if 'style="' in t: t=t.replace('style="','style="fill:'+f.group(1)+';',1)
                    else: t=re.sub(r'^<(text|tspan)',lambda q:'<'+q.group(1)+' style="fill:'+f.group(1)+'"',t,1)
                return t
            return re.sub(r'<(?:text|tspan)\b[^>]*>',tag,s)
        new=[fixtext(x) for x in new]
        it=iter(new)
        n_old=len(old_svgs(i)); assert len(new)==n_old,f'{i}: need {n_old} svgs, got {len(new)}'
        h=SVG_RE.sub(lambda m:next(it),h)
    a=f'{HERE}/cards/{i}.anchors.json'
    if os.path.exists(a):
        anc=json.load(open(a)); assert len(anc)==len(notes),f'{i}: need {len(notes)} anchors, got {len(anc)}'
        for n,x in zip(notes,anc): n['a']=x
    return h,notes
if __name__=='__main__':
    out=json.loads(json.dumps(D))
    for i in out['frames']:
        h,n=apply(i); out['frames'][i]['html']=h; out['NOTES'][i]=n
    json.dump(out,open(HERE+'/src/data2.json','w'),ensure_ascii=False); print('ok')
