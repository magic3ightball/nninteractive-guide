import sys,json,os
from playwright.sync_api import sync_playwright
HERE=os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0,HERE); import merge
ids=sys.argv[1:]
css=open(HERE+'/src/orig.css').read()+open(HERE+'/src/legacy.css').read()
JS='''
const NOTES=%s;
const fr=document.querySelector('.frame');
function anchor(a){const fb=fr.getBoundingClientRect();
 if(a.svg){const svg=fr.querySelectorAll('svg.fig')[a.i||0];const p=svg.createSVGPoint();p.x=a.svg[0];p.y=a.svg[1];const q=p.matrixTransform(svg.getScreenCTM());return{x:q.x-fb.left,y:q.y-fb.top}}
 const el=fr.querySelectorAll(a.sel)[a.i||0];const r=el.getBoundingClientRect();const x=a.at==='l'?r.left+14:a.at==='c'?(r.left+r.right)/2:r.right+16;return{x:x-fb.left,y:(r.top+r.bottom)/2-fb.top}}
NOTES.forEach((n,i)=>{try{const p=anchor(n.a);const d=document.createElement('div');d.className='pin';d.textContent=i+1;d.style.left=p.x+'px';d.style.top=p.y+'px';fr.appendChild(d)}catch(e){console.error('anchor '+(i+1)+' failed: '+e)}});
'''
with sync_playwright() as p:
    b=p.chromium.launch()
    for i in ids:
        h,notes=merge.apply(i)
        page=f'<!doctype html><html lang="ko"><head><meta charset="utf-8"><style>{css}\nbody{{margin:0;padding:40px;background:var(--bg);overflow:visible}} .frame{{position:relative!important;width:1040px}}</style></head><body><div class="frame"><div class="fbody">{h}</div></div><script>{JS%json.dumps(notes,ensure_ascii=False)}</script></body></html>'
        open(f'{HERE}/preview/{i}.html','w',encoding='utf8').write(page)
        pg=b.new_page(viewport={'width':1130,'height':900}); errs=[]
        pg.on('console',lambda m:m.type=='error' and errs.append(m.text)); pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('file://'+f'{HERE}/preview/{i}.html'); pg.wait_for_timeout(500)
        pg.locator('.frame').screenshot(path=f'{HERE}/preview/{i}.png'); print(i,'errors:',errs); pg.close()
    b.close()
